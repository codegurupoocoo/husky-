# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

CORS_ORIGIN_WHITELIST = ["http://0.0.0.0:4000", "http://localhost:4000"]
