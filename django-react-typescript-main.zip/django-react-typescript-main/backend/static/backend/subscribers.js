window.onload = function () {
  document.getElementById("searchbar").placeholder =
    "Search for name or neighborhood";
};
