export enum ROUTES {
  LANDING_PAGE = "/",
  BLOG = "/blog",
  PUBLICATION_PAGE = "/blog/:publication",
}
