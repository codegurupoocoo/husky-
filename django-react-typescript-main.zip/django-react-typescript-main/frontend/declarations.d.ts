declare module "*.png" {
  const value: string;
  export default value;
}

declare module "*.woff2" {
  const path: string;
  export default path;
}
